using Project_N28;
using NUnit.Framework;
using System.Xml.Linq;
using Moq;
using System.IO;

namespace UnitTest
{

    [TestFixture]
    public class ParserTests
    {
   
        private const string xmlTempFileContent = @"<Root><Element Name=""TestName"">Value1</Element></Root>";
        private string tempLogDir;

        // Percorsi temporanei per "l'input"
        private const string ExpectedConfPath = "FakeInput/conf.xml";
        private const string ExpectedAPath = "FakeInput/A.xml";
        private const string ExpectedBPath = "FakeInput/B.xml";

        // Contenuto minimo per i mock
        private XDocument GetMockXDocument() => new XDocument(new XElement("Root"));

        [SetUp]
        public void Setup()
        {
            // 1. Directory temporanea (reale) per i servizi I/O
            tempLogDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempLogDir);

            // 2. Inizializzazione di tutte le classi I/O statiche
            // Questo � fondamentale per evitare NullReferenceException all'interno di FileWrite/Logger/Mapping
            Logger.SetOutputFilePath(tempLogDir);
            FileWrite.SetOutputFilePath(tempLogDir);
            Mapping.SetOutputFilePath(tempLogDir);
        }

        [TearDown]
        public void TearDown()
        {
            // Pulizia
            if (Directory.Exists(tempLogDir))
            {
                Directory.Delete(tempLogDir, true);
            }
        }


        [Test]
        public void P01_FileLoader_CaricamentoRiuscito()
        {
            //Preparo un file XML fittizio valido su disco o come stringa.
            string tempFilePath = System.IO.Path.GetTempFileName();
            System.IO.File.WriteAllText(tempFilePath, xmlTempFileContent);

            //inizializzazione del file loader e first log
            Parser parser = new Parser();
            bool firstLog = true;

            //Chiamo FileLoader con il percorso del file fittizio.
            XDocument testXML = parser.FileLoader(firstLog, tempFilePath);

            // ASSERT
            Assert.That(testXML, Is.Not.Null);
            Assert.That(testXML.Root.Name.LocalName, Is.EqualTo("Root"));

            // CLEANUP: Eliminazione del file temporaneo specifico del test
            if (File.Exists(tempFilePath))
            {
                File.Delete(tempFilePath);
            }
        }

        [Test]
        public void P02_FlussoFileCaricamento_VerificaPercorsoPassato()
        {
            // ARRANGE: Setup del mock per il parser
            var mockParser = new Mock<IParser>();
            var emptyNodoList = new List<Nodo>();
            var emptyEnteList = new List<Ente>();

            // Mock per FileLoader e LoadNomeImpianto
            mockParser.Setup(p => p.FileLoader(It.IsAny<bool>(), It.IsAny<string>())).Returns(GetMockXDocument());
            mockParser.Setup(p => p.LoadNomeImpianto(It.IsAny<XDocument>(), It.IsAny<XDocument>(), It.IsAny<XNamespace?>())).Returns("ImpiantoTest");

            // Mock per le liste di configurazione (Restituiscono liste vuote)
            mockParser.Setup(p => p.parseConfFIleNodes(It.IsAny<XDocument>(), It.IsAny<XNamespace>())).Returns(emptyNodoList);
            mockParser.Setup(p => p.parseConfFileEnti(It.IsAny<XDocument>(), It.IsAny<XNamespace>())).Returns(emptyEnteList);

            // Mock per ParseNodi e ParseEnti (Tool A e B)
            mockParser.Setup(p => p.ParseNodi(It.IsAny<List<Nodo>>(), It.IsAny<XDocument>(), It.IsAny<string>(), It.IsAny<XNamespace>())).Returns(emptyNodoList);
            mockParser.Setup(p => p.ParseEnti(It.IsAny<List<Ente>>(), It.IsAny<XDocument>(), It.IsAny<string>(), It.IsAny<XNamespace>())).Returns(emptyEnteList);

            // Mock per CheckTwoFiles (Restituisce sempre nessuna discrepanza)
            

            // Setup del mock per il fileBrowser
            var mockFileBrowser = new Mock<IFileBrowser>();

            mockFileBrowser.SetupSequence(fb => fb.GetFilePath(It.IsAny<string>()))
                           .Returns(ExpectedConfPath) // 1. conf_filename
                           .Returns(ExpectedAPath)    // 2. A_filename
                           .Returns(ExpectedBPath);    // 3. B_filename

            // Setup della risposta per GetOutputDirectory
            mockFileBrowser.Setup(fb => fb.GetOutputDirectory()).Returns(tempLogDir);

            // ACT: Istanziare ed eseguire il main
            var main = new MainClass(mockParser.Object, mockFileBrowser.Object);
            main.Run();

            // ASSERT: Verifica dei risultati (i percorsi, i conteggi, ecc.)

            // 1. VERIFICA l'INPUT
            mockFileBrowser.Verify(b => b.GetFilePath(It.IsAny<string>()), Times.Exactly(3),
                                   "GetFilePath non � stato chiamato per tutti e tre i file di input.");

            // 2. VERIFICA il FLUSSO
            mockParser.Verify(p => p.FileLoader(It.IsAny<bool>(), It.IsAny<string>()), Times.Exactly(3),
                                 "FileLoader non � stato chiamato il numero di volte corretto (Config, A, B).");

            // 3. VERIFICA degli ARGOMENTI (La Prova Reale)
            mockParser.Verify(p => p.FileLoader(true, ExpectedConfPath), Times.Once,
                                 "FileLoader per la configurazione non � stato chiamato con il percorso e l'argomento firstLog attesi.");
            mockParser.Verify(p => p.FileLoader(false, ExpectedAPath), Times.Once,
                                 "FileLoader per Tool A non � stato chiamato con il percorso atteso (firstLog=false).");
            mockParser.Verify(p => p.FileLoader(false, ExpectedBPath), Times.Once,
                                 "FileLoader per Tool B non � stato chiamato con il percorso atteso (firstLog=false).");

            // Verifica che l'intero flusso Run() sia terminato
            Assert.Pass("Il flusso di Run() � stato completato senza eccezioni grazie al mocking completo.");
        }

        [Test]
        public void P03_LoadNomeImpianto_CorrettezzaEstrazione()
        {
            const string expectedImpiantoName = "ImpiantoTest";

            var conf_file = new XDocument(
                new XElement("grafo",
                    new XElement("impianto", expectedImpiantoName)
                )
            );

            var fileA = new XDocument(
                new XElement("grafo",
                    new XElement("impianto", expectedImpiantoName)
                )
            );

            var parser = new Parser();

            string result = parser.LoadNomeImpianto(conf_file, fileA, XNamespace.None);

            Assert.That(result, Is.EqualTo(expectedImpiantoName), "Il nome dell'impianto estratto non corrisponde a quello atteso.");
        }

        // P04: Parsing Nodi Configurazione
        [Test]
        public void P04_parseConfFIleNodes_CorrettezzaParsing()
        {
            //Preparazione di un finto config.xml 
            const int expectedNodeCount = 3;
            var config_xml = new XDocument(
                new XElement("grafo",
                    new XElement("nodo",
                        new XElement("categoria", "DEVIATOIO"),
                        new XElement("tipo", "SEMPLICE"),
                        new XElement("nome", "02"),
                        new XElement("classe", "PESANTE")
                    ),
                    new XElement("nodo",
                       new XElement("categoria", "DEVIATOIO"),
                       new XElement("tipo", "SEMPLICE"),
                       new XElement("nome", "01"),
                       new XElement("classe", "PESANTE")
                    ),
                     new XElement("nodo",
                        new XElement("categoria", "DEVIATOIO"),
                        new XElement("tipo", "SEMPLICE"),
                        new XElement("nome", "85"),
                        new XElement("classe", "PESANTE")
                     )
                )
            );

            // Inizializzazione del parser e dei nodi 
            var parser = new Parser();
            List<Nodo> nodiRicavati = parser.parseConfFIleNodes(config_xml, XNamespace.None);

            Assert.That(nodiRicavati.Count, Is.EqualTo(expectedNodeCount), "Il numero di nodi parsati non corrisponde a quello atteso.");
            
            //Verifico che i valori siano stati presi correttamente
            Nodo nodo1 = nodiRicavati.Find(n => n.Nome == "01");
            Assert.Multiple(() =>
            {
                Assert.That(nodo1, Is.Not.Null, "Nodo con Nome '01' non trovato nella lista parsata.");
                Assert.That(nodo1.Categoria, Is.EqualTo("DEVIATOIO"), "Categoria del nodo 01 non corrisponde.");
                Assert.That(nodo1.Tipo, Is.EqualTo("SEMPLICE"), "Tipo del nodo 01 non corrisponde.");
                Assert.That(nodo1.Classe, Is.EqualTo("PESANTE"), "Classe del nodo 01 non corrisponde.");
            });

            Nodo nodo2 = nodiRicavati.Find(n => n.Nome == "02");
            Assert.Multiple(() =>
            {
                Assert.That(nodo2, Is.Not.Null, "Nodo con Nome '02' non trovato nella lista parsata.");
                Assert.That(nodo2.Categoria, Is.EqualTo("DEVIATOIO"), "Categoria del nodo 02 non corrisponde.");
                Assert.That(nodo2.Tipo, Is.EqualTo("SEMPLICE"), "Tipo del nodo 02 non corrisponde.");
                Assert.That(nodo2.Classe, Is.EqualTo("PESANTE"), "Classe del nodo 02 non corrisponde.");
            });

            Nodo nodo85 = nodiRicavati.Find(n => n.Nome == "85");
            Assert.Multiple(() =>
            {
                Assert.That(nodo85, Is.Not.Null, "Nodo con Nome '85' non trovato nella lista parsata.");
                Assert.That(nodo85.Categoria, Is.EqualTo("DEVIATOIO"), "Categoria del nodo 85 non corrisponde.");
                Assert.That(nodo85.Tipo, Is.EqualTo("SEMPLICE"), "Tipo del nodo 85 non corrisponde.");
                Assert.That(nodo85.Classe, Is.EqualTo("PESANTE"), "Classe del nodo 85 non corrisponde.");
            });
        }

        [Test]
        public void P05_ParseNodi_FiltroCategoriaCorretto()
        {
            //Preparazione dei dati
           const string categoriaInteressata = "DEVIATOIO";
           const int expectedCount = 2; 
            List<Nodo> configNodi = new List<Nodo>()
           {
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE" },
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE" },
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "85", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE" } 
           };
            var fileXML = new XDocument(
                new XElement("grafo",
                    new XElement("nodo",
                        new XElement("categoria", "DEVIATOIO"),
                        new XElement("tipo", "SEMPLICE"),
                        new XElement("nome", "02"),
                        new XElement("classe", "PESANTE"),
                        new XElement("id", "882",
                            new XAttribute("x", "2864.01"),
                            new XAttribute("y", "990.22")
                        )
                    ),
                    new XElement("nodo",
                       new XElement("categoria", "DEVIATOIO"),
                       new XElement("tipo", "SEMPLICE"),
                       new XElement("nome", "01"),
                       new XElement("classe", "PESANTE"),
                       new XElement("id", "944",
                            new XAttribute("x", "2493.81"),
                            new XAttribute("y", "990.22")
                       )
                    ),
                     new XElement("nodo",
                        new XElement("categoria", "---"),
                        new XElement("tipo", "---"),
                        new XElement("nome", "99"),
                        new XElement("classe", "----"),
                        new XElement("id", "944",
                            new XAttribute("x", "2493.81"),
                            new XAttribute("y", "990.22")
                       )
                     ),
                     new XElement("nodo",
                        new XElement("categoria", "STAZIONAMENTO"),
                        new XElement("tipo", "CENTRALIZZATO"),
                        new XElement("nome", "II"),
                        new XElement("classe", "AMBIVERSO"),
                        new XElement("id", "944",
                            new XAttribute("x", "2493.81"),
                            new XAttribute("y", "990.22")
                       )
                     ),
                     new XElement("nodo",
                        new XElement("categoria", "SEGNALE BASSO"),
                        new XElement("tipo", "PICCHETTO DI MANOVRA"),
                        new XElement("nome", "IGNOTO"),
                        new XElement("classe", "DESTRO"),
                        new XElement("id", "944",
                            new XAttribute("x", "2493.81"),
                            new XAttribute("y", "990.22")
                       )
                     ),
                     new XElement("nodo",
                        new XElement("categoria", "PIEDE"),
                        new XElement("tipo", "TRAVERSA LIMITE"),
                        new XElement("nome", "02-CR"),
                        new XElement("classe", "LEGGERO"),
                        new XElement("id", "944",
                            new XAttribute("x", "2493.81"),
                            new XAttribute("y", "990.22")
                       )
                     )
                )
            );
            var parser = new Parser();
            List<Nodo> nodiEstratti = parser.ParseNodi(configNodi, fileXML, categoriaInteressata, XNamespace.None);

            Assert.That(nodiEstratti.Count, Is.EqualTo(expectedCount), "Il numero di nodi estratti non corrisponde a quello atteso.");

            Nodo nodo1 = nodiEstratti.Find(n => n.Nome == "01");
            Assert.Multiple(() =>
            {
                Assert.That(nodo1, Is.Not.Null, "Nodo con Nome '01' non trovato nella lista estratta.");
                Assert.That(nodo1.Categoria, Is.EqualTo("DEVIATOIO"), "Categoria del nodo 01 non corrisponde.");
                Assert.That(nodo1.Tipo, Is.EqualTo("SEMPLICE"), "Tipo del nodo 01 non corrisponde.");
                Assert.That(nodo1.Classe, Is.EqualTo("PESANTE"), "Classe del nodo 01 non corrisponde.");
            });

            Nodo nodo2 = nodiEstratti.Find(n => n.Nome == "02");
            Assert.Multiple(() =>
            {
                Assert.That(nodo2, Is.Not.Null, "Nodo con Nome '02' non trovato nella lista estratta.");
                Assert.That(nodo2.Categoria, Is.EqualTo("DEVIATOIO"), "Categoria del nodo 02 non corrisponde.");
                Assert.That(nodo2.Tipo, Is.EqualTo("SEMPLICE"), "Tipo del nodo 02 non corrisponde.");
                Assert.That(nodo2.Classe, Is.EqualTo("PESANTE"), "Classe del nodo 02 non corrisponde.");
            });
        }
    }

    [TestFixture]
    public class ComparatorTests
    {
        //Campi, setup e teardown sono analoghi a quelli di ParserTests, tranne per tmpFileContent e il GetMockXDocument

        private string tempLogDir;

        // Percorsi temporanei per "l'input"
        private const string ExpectedConfPath = "FakeInput/conf.xml";
        private const string ExpectedAPath = "FakeInput/A.xml";
        private const string ExpectedBPath = "FakeInput/B.xml";

        [SetUp]
        public void Setup()
        {
            // 1. Directory temporanea (reale) per i servizi I/O
            tempLogDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempLogDir);

            // 2. Inizializzazione di tutte le classi I/O statiche
            // Questo � fondamentale per evitare NullReferenceException all'interno di FileWrite/Logger/Mapping
            Logger.SetOutputFilePath(tempLogDir);
            FileWrite.SetOutputFilePath(tempLogDir);
            Mapping.SetOutputFilePath(tempLogDir);
        }

        [TearDown]
        public void TearDown()
        {
            // Pulizia
            if (Directory.Exists(tempLogDir))
            {
                Directory.Delete(tempLogDir, true);
            }
        }

        
        [Test]
        public void C01_CheckTwoFilesNodi_CorrispondenzaPerfetta()
        {
            // Preparazione delle liste di Nodi A e B identiche.
            var listA = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 },
                new Nodo { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=249381, Y=99022 }
            };
            var listB = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 },
                new Nodo { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=249381, Y=99022 }
            };
            
            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Nodo>(
                listA,
                listB,
                Comparators.getKeyNodo,
                Comparators.NodoComparators, 
                "Nodo"
            );

            Assert.That(differenza, Is.False, "Non dovrebbero esserci discrepanze per liste identiche.");
        
        }

        [Test]
        public void C02_CheckTwoFilesNodi_ElementoMancanteInB()
        {
            // Preparazione delle liste di Nodi A e B, elemento in pi� in A
            var listA = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 },
                new Nodo { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=249381, Y=99022 }
            };
            var listB = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 }
            };

            //Esecuzione del metodo
            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Nodo>(
                listA,
                listB,
                Comparators.getKeyNodo,
                Comparators.NodoComparators, 
                "Nodo"
            );

            //Controllo del risultato
            Assert.That(differenza, Is.True, "Dovrebbe essere rilevata una discrepanza per l'elemento mancante in B.");

        }

        // C03: Discrepanza Contenuto (X/Y)
        [Test]
        public void C03_CheckTwoFilesNodi_DiscrepanzaContenuto()
        {
            // Preparazione delle liste di Nodi A e B, elemento in pi� in A
            var listA = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 },
                new Nodo { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=249381, Y=99022 }
            };
            var listB = new List<Nodo>
            {
                new Nodo { Nome = "01", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=882, X=286401, Y=99022 },
                new Nodo { Nome = "02", Categoria = "DEVIATOIO", Tipo = "SEMPLICE", Classe = "PESANTE", Id=987, X=346846, Y=76861 }
            };

            //Esecuzione del metodo
            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Nodo>(
                listA,
                listB,
                Comparators.getKeyNodo,
                Comparators.NodoComparators, 
                "Nodo"
            );

            //Controllo del risultato
            Assert.That(differenza, Is.True, "Dovrebbe essere rilevata una discrepanza a causa delle differenze nei dettagli interni.");
        }

        // C04: Corrispondenza Perfetta Enti
        [Test]
        public void C04_CheckTwoFilesEnti_CorrispondenzaPerfetta()
        {
            // Preparazione delle liste di Enti A e B identiche.
            var listA = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2025, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=293383, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=99022 },
                new Ente { Nome = "112", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=3476, X=252426, Y=99022 }
            };
            var listB = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2025, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=293383, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=99022 },
                new Ente { Nome = "112", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=3476, X=252426, Y=99022 }
            };

            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Ente>(
                listA,
                listB,
                Comparators.getKeyEnte,
                Comparators.EnteComparators,
                "Ente"
            );

            Assert.That(differenza, Is.False, "Non dovrebbero esserci discrepanze per liste identiche.");
        }

        // C05: Ente Mancante in A
        [Test]
        public void C05_CheckTwoFilesEnti_ElementoMancanteInA()
        {
            // Preparazione delle liste di Enti A e B dove B ha pi� elementi di A
            var listA = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2025, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=293383, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=99022 }

            };
            var listB = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2025, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=293383, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=99022 },
                new Ente { Nome = "112", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=3476, X=252426, Y=99022 }
            };

            //Esecuzione del metodo
            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Ente>(
                listA,
                listB,
                Comparators.getKeyEnte,
                Comparators.EnteComparators,
                "Ente"
            );

            //Controllo del risultato
            Assert.That(differenza, Is.True, "Dovrebbe essere rilevata una discrepanza per l'elemento mancante in B.");
        }

        // C06: Test Attributo Singolo (Classe)
        [Test]
        public void C06_NodoComparators_RilevaDiscrepanza()
        {
            var listA = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2025, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=293383, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=99022 },
                new Ente { Nome = "112", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=3476, X=252426, Y=99022 }
            };
            var listB = new List<Ente>
            {
                new Ente { Nome = "120", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=8239, X=30546, Y=99022 },
                new Ente { Nome = "121", Categoria = "CDB", Tipo = "STAZIONE", Classe = "SENZA ENTI", Id=2882, X=747673, Y=99022 },
                new Ente { Nome = "122", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=2986, X=283428, Y=297998 },
                new Ente { Nome = "112", Categoria = "CDB", Tipo = "STAZIONE", Classe = "CON ENTI", Id=3476, X=252426, Y=99022 }
            };

            //Esecuzione del metodo
            var parser = new Parser();
            bool differenza = parser.CheckTwoFiles<Ente>(
                listA,
                listB,
                Comparators.getKeyEnte,
                Comparators.EnteComparators,
                "Ente"
            );

            //Controllo del risultato
            Assert.That(differenza, Is.True, "Dovrebbe essere rilevata una discrepanza a causa dei valori differenti");

        }
    }

    [TestFixture]
    public class IOMappingHelperTests
    {
        private string tmpResDir;
        private string outputReportPath;
        private string outputLoggerPath;

        [SetUp]
        public void Setup()
        {
            // 1. Directory temporanea (reale) per i servizi I/O
            tmpResDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tmpResDir);

            // 2. Inizializzazione di tutte le classi I/O statiche
            // Questo � fondamentale per evitare NullReferenceException all'interno di FileWrite/Logger/Mapping
            Logger.SetOutputFilePath(tmpResDir);
            FileWrite.SetOutputFilePath(tmpResDir);
            Mapping.SetOutputFilePath(tmpResDir);

            outputReportPath = Path.Combine(tmpResDir, "Report.txt");
            outputLoggerPath = Path.Combine(tmpResDir, "Log.txt");
        }

        [TearDown]
        public void TearDown()
        {
            // Pulizia
            if (Directory.Exists(tmpResDir))
            {
                Directory.Delete(tmpResDir, true);
            }
        }

        [Test]
        public void I01_FileWrite_ScritturaReport()
        {
            var content = "Prima riga di prova.";

            // Scrive il contenuto, sovrascrivendo (append: false)
            FileWrite.Write(content, false);

            // Legge tutte le righe dal file
            var lines = File.ReadAllLines(outputReportPath);

            // Prime Verifiche
            Assert.That(File.Exists(outputReportPath), $"Il file non � stato creato in {outputReportPath}");
            Assert.That(lines.Length, Is.EqualTo(1), "Il file dovrebbe contenere esattamente 1 riga.");
            Assert.That(lines[0], Is.EqualTo(content), "Il contenuto della riga non corrisponde.");

            // Scrive di nuovo, questa volta in append
            var additionalContent = "Seconda riga di prova.";
            FileWrite.Write(additionalContent, true);
            lines = File.ReadAllLines(outputReportPath);

            // Verifiche Finali
            Assert.That(lines.Length, Is.EqualTo(2), "Il file dovrebbe contenere esattamente 2 righe dopo l'append.");
            Assert.That(lines[1], Is.EqualTo(additionalContent), "Il contenuto della seconda riga non corrisponde.");
        }

        // I02: Inizializzazione Log
        [Test]
        public void I02_Logger_GestioneFirstLog()
        {
            //Inizializzazione
            var firstMessage = "Primo messaggio di log.";
            var secondMessage = "Secondo messaggio di log.";
            
            // Primo log (firstLog: true)
            Logger.Log(firstMessage, true);
            var lines = File.ReadAllLines(outputLoggerPath);
            
            // Verifiche dopo il primo log
            Assert.That(File.Exists(outputLoggerPath), $"Il file di log non � stato creato in {outputLoggerPath}");
            Assert.That(lines.Length, Is.EqualTo(1), "Il file di log dovrebbe contenere esattamente 1 riga dopo il primo log.");
            Assert.That(lines[0].Contains(firstMessage), "Il contenuto del primo log non corrisponde.");
            
            // Secondo log (firstLog: false)
            Logger.Log(secondMessage, false);
            lines = File.ReadAllLines(outputLoggerPath);
            
            // Verifiche dopo il secondo log
            Assert.That(lines.Length, Is.EqualTo(2), "Il file di log dovrebbe contenere esattamente 2 righe dopo il secondo log.");
            Assert.That(lines[1].Contains(secondMessage), "Il contenuto del secondo log non corrisponde.");
        }

        // M01: Mapping Riuscito
        [Test]
        public void M01_BuildMapFile_AssociazioniCorrette()
        {
            //Preparazione liste di Nodi A e B con corrispondenze, e non, note.
            var nodiA = new List<Nodo>
            {
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "01", Id = 101 }, // Corrisponde
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "02", Id = 102 }  // Solo in A
            };
            var nodiB = new List<Nodo>
            {
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "01", Id = 201 }, // Corrisponde
                new Nodo(new XElement("nodo"), XNamespace.None) { Nome = "03", Id = 203 }  // Solo in B
            };

            // Esecuzione del metodo
            var mapping = Mapping.BuildMapFile(nodiA, nodiB, n => n.Nome, n => n.Id, "Nodo");

            // Verifiche
            Assert.That(mapping.Count, Is.EqualTo(3), "Il numero di elementi nel mapping non � corretto.");

            var map01 = mapping.Find(m => m.nome == "01");
            Assert.That(map01.idA, Is.EqualTo(101), "ID A per nodo 01 non corretto.");
            Assert.That(map01.idB, Is.EqualTo(201), "ID B per nodo 01 non corretto.");

            var map02 = mapping.Find(m => m.nome == "02");
            Assert.That(map02.idA, Is.EqualTo(102), "ID A per nodo 02 non corretto.");
            Assert.That(map02.idB, Is.Null, "ID B per nodo 02 dovrebbe essere nullo.");

            var map03 = mapping.Find(m => m.nome == "03");
            Assert.That(map03.idA, Is.Null, "ID A per nodo 03 dovrebbe essere nullo.");
            Assert.That(map03.idB, Is.EqualTo(203), "ID B per nodo 03 non corretto.");
        }

        
        [Test]
        public void M02_WriteMapToXML_AppendFunzionante()
        {
            // ARRANGE: Prepara due liste di mapping (Nodi e Enti) e un percorso file temporaneo.
            var nodiMapping = new List<(string entityName, string nome, double? idA, double? idB)>
            {
                ("Nodo", "01", 101, 201)
            };
            var entiMapping = new List<(string entityName, string nome, double? idA, double? idB)>
            {
                ("Ente", "E01", 301, 401)
            };
            
            string tempMapFile = Path.Combine(tmpResDir, "mapping.xml");
            Mapping.SetOutputFilePath(tmpResDir);

            // ACT: 
            // 1. Chiama WriteMapToXML(NodiMapping, false); 
            Mapping.WriteMapToXML(nodiMapping, false);
            // 2. Chiama WriteMapToXML(EntiMapping, true);
            Mapping.WriteMapToXML(entiMapping, true);

            // ASSERT: Leggi il file XML e verifica che contenga sia i tag di mapping dei Nodi che quelli degli Enti.
            Assert.That(File.Exists(tempMapFile), Is.True, "Il file di mapping non � stato creato.");

            XDocument doc = XDocument.Load(tempMapFile);
            Assert.That(doc.Root, Is.Not.Null);
            Assert.That(doc.Root.Name.LocalName, Is.EqualTo("mapping"));
            Assert.That(doc.Root.Elements("nodo").Count(), Is.EqualTo(1), "Il mapping dei nodi non � stato scritto correttamente.");
            Assert.That(doc.Root.Elements("ente").Count(), Is.EqualTo(1), "Il mapping degli enti non � stato accodato correttamente.");
        }

        // H01: Gestione Lista Vuota
        [Test]
        public void H01_PrintConfigNodes_GestioneListaVuota()
        {
            // ARRANGE: Prepara una lista vuota di Nodi.
            var emptyNodeList = new List<Nodo>();
            var mockConsole = new StringWriter();
            Console.SetOut(mockConsole);

            // ACT: Chiama PrintConfigNodes
            MainClass.PrintConfigNodes(emptyNodeList);

            // ASSERT: Verifica che la stringa "(nessun nodo di configurazione)" sia stata scritta in console e su file.
            string consoleOutput = mockConsole.ToString();
            Assert.That(consoleOutput, Does.Contain("(nessun nodo di configurazione)"), "L'output in console per la lista vuota non � corretto.");

        }
    }
}