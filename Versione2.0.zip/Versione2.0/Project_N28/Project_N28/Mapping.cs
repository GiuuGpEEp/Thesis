﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO;

namespace Project_N28
{
    public static class Mapping
    {
        private static string outputPath = "";

        public static void SetOutputFilePath(string directory)
        {
            outputPath = Path.Combine(directory, "mapping.xml");
        }
        public static List<(string entityName, string nome, double? idA, double? idB)> BuildMapFile<T>(
            List<T> elemFileA,
            List<T> elemFileB,
            Func<T, string> getKey,
            Func<T, double> getId,
            string entityName
            )
        {
            var mapping = new List<(string entityName, string nome, double? idA, double? idB)>();

            var dictFileA = elemFileA.ToDictionary(getKey, elem => elem);
            var dictFileB = elemFileB.ToDictionary(getKey, elem => elem);

            foreach(var elemA in elemFileA)
            {
                var elemName = getKey(elemA);
                if(dictFileB.TryGetValue(elemName, out var elemB))
                {
                    mapping.Add((entityName, elemName, getId(elemA), getId(elemB)));
                }
                else
                {
                    mapping.Add((entityName, elemName, getId(elemA), null)); // -1 indica che non è stato trovato in B
                }
            }

            // Secondo passaggio: elementi presenti solo in B
            foreach (var elemB in elemFileB)
            {
                var elemName = getKey(elemB);
                if (!dictFileA.ContainsKey(elemName))
                {
                    mapping.Add((entityName, elemName, null, getId(elemB)));
                }
            }

            return mapping;
        }


        public static void WriteMapToXML(
            List<(string entityName, string nome, double? idA, double? idB)> mapping,
            bool append
            )
        {
            XDocument doc;
            XElement root;

            if (File.Exists(outputPath) && append)
            {
                // Append su file esistente
                doc = XDocument.Load(outputPath);
                root = doc.Root ?? new XElement("mapping");
                if (doc.Root == null)
                {
                    doc.Add(root);
                }
            }
            else
            {
                // Crea nuovo documento
                root = new XElement("mapping");
                doc = new XDocument(new XDeclaration("1.0", "", ""), root);
            }

            foreach (var m in mapping)
            {
                var entityTag = m.entityName == "Nodo" ? "nodo" : "ente";
                var mapElement = new XElement(entityTag,
                    new XAttribute("nome", m.nome),
                    new XAttribute("id-A", m.idA?.ToString() ?? string.Empty),
                    new XAttribute("id-B", m.idB?.ToString() ?? string.Empty)
                );
                root.Add(mapElement);
            }

            doc.Save(outputPath);
        }
    }
}
