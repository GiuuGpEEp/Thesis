﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project_N28
{
    public class Nodo
    {
        public double Id { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double O { get; set; }
        public string Flip { get; set; }
        public string Mir { get; set; }
        public string Categoria { get; set; }
        public string Tipo { get; set; }
        public string Classe { get; set; }
        public string Nome { get; set; }
        public double Xf { get; set; }
        public double Yf { get; set; }
        public Dictionary<string, string> Attributi { get; set; }
        public List<Porta> Porte { get; set; }

        public Nodo(XElement nodeElement, XNamespace ns)
        {
            Id = double.Parse(nodeElement.Attribute("id")?.Value ?? "0");
            X = double.Parse(nodeElement.Attribute("x")?.Value ?? "0");
            Y = double.Parse(nodeElement.Attribute("y")?.Value ?? "0");
            O = double.Parse(nodeElement.Attribute("o")?.Value ?? "0");
            Flip = nodeElement.Attribute("flip")?.Value ?? "";
            Mir = nodeElement.Attribute("mir")?.Value ?? "";
            Categoria = nodeElement.Element(ns + "categoria")?.Value ?? "";
            Tipo = nodeElement.Element(ns + "tipo")?.Value ?? "";
            Classe = nodeElement.Element(ns + "classe")?.Value ?? "";
            Nome = nodeElement.Element(ns + "nome")?.Value ?? "";
            Xf = double.Parse(nodeElement.Element(ns + "xf")?.Value ?? "0");
            Yf = double.Parse(nodeElement.Element(ns + "yf")?.Value ?? "0");
            Attributi = nodeElement.Element(ns + "attributi")?
                        .Elements(ns + "attributo")
                        .ToDictionary(
                            attributo => attributo.Attribute("nome")?.Value ?? "",
                            attributo => attributo.Attribute("valore")?.Value ?? ""
                            ) ?? new Dictionary<string, string>();
            Porte = nodeElement.Elements(ns + "porta")? //Tramite Elements ho la garanzia che mi venga ritornato un IEnumerable di oggetti di tipo XElement
                    .Select(p => new Porta(p))
                    .ToList() ?? new List<Porta>();
        }
        public Nodo() {}
    }
    
    public class Porta
    {
        public string Nome { get; set; }
        public double X { get; set; }
        public double Y { get; set; }

        public Porta(XElement portaElement)
        {
            Nome = portaElement.Attribute("nome")?.Value ?? "";
            X = double.Parse(portaElement.Attribute("x")?.Value ?? "0");
            Y = double.Parse(portaElement.Attribute("y")?.Value ?? "0");
        }
    }

    public class Ente
    {
        public double Id { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double O { get; set; }
        public string Flip { get; set; }
        public string Mir { get; set; }
        public string Categoria { get; set; }
        public string Tipo { get; set; }
        public string Classe { get; set; }
        public string Nome { get; set; }
        public Dictionary<string, string> Attributi { get; set; }

        public Ente(XElement enteElement, XNamespace ns)
        {
            Id = double.Parse(enteElement.Attribute("id")?.Value ?? "0");
            X = double.Parse(enteElement.Attribute("x")?.Value ?? "0");
            Y = double.Parse(enteElement.Attribute("y")?.Value ?? "0");
            O = double.Parse(enteElement.Attribute("o")?.Value ?? "0");
            Flip = enteElement.Attribute("flip")?.Value ?? "";
            Mir = enteElement.Attribute("mir")?.Value ?? "";
            Categoria = enteElement.Element(ns + "categoria")?.Value ?? "";
            Tipo = enteElement.Element(ns + "tipo")?.Value ?? "";
            Classe = enteElement.Element(ns + "classe")?.Value ?? "";
            Nome = enteElement.Element(ns + "nome")?.Value ?? "";
            Attributi = enteElement.Element(ns + "attributi")?
                        .Elements(ns + "attributo")
                        .ToDictionary(
                            attributo => attributo.Attribute("nome")?.Value ?? "",
                            attributo => attributo.Attribute("valore")?.Value ?? ""
                            ) ?? new Dictionary<string, string>();
        }

        public Ente() { }
    }
}
