﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project_N28
{
    public static class FileWrite
    {
        private static string outputFile = "";

        public static void SetOutputFilePath(string path)
        {
            outputFile = Path.Combine(path, "Report.txt");
        }
        public static void Write(string content, bool append)
        {
            using (StreamWriter writer = new StreamWriter(outputFile, append: append))
            {
                writer.WriteLine(content);
            }
        }

        public static void WriteMissingElement(string fileName, string entityName, string elemName) //Metodo usato in CheckTwoFiles nel file Parser per evitare stampe duplicate
        {
            var line = $"{entityName} {elemName} non trovato nel {fileName} file.";
            Console.WriteLine(line);
            FileWrite.Write(line, true);
        }
    }

}
