﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project_N28
{
    public class Parser : IParser
    {
        

        public XDocument FileLoader(bool firstLog, string filepath)
        {
            Logger.Log("Avvio caricamento file XML: " + filepath, firstLog);
            XDocument file = XDocument.Load(filepath);
            Logger.Log("Caricamento completato", false); // non sovrascrivere il primo messaggio
            return file;
        }

        public string LoadNomeImpianto(XDocument conf_file, XDocument file, XNamespace? ns = null)
        {

            var confRoot = conf_file.Root;
            var fileRoot = file.Root;

            if (confRoot == null || fileRoot == null)
                return string.Empty;

            var impiantoConf = confRoot.Element(ns + "impianto")?.Value;
            var impiantoFile = fileRoot.Element(ns + "impianto")?.Value;

            return impiantoConf == impiantoFile ? impiantoConf : string.Empty;
        }

        public List<Nodo> parseConfFIleNodes(XDocument conf_file, XNamespace? ns = null)
        {
            var confNodi = new List<Nodo>();
            foreach (var confNodeElement in conf_file.Descendants(ns + "nodo"))
            {
                var confNode = new Nodo(confNodeElement, ns);
                confNodi.Add(confNode);
            }
            return confNodi;
        }

        public List<Ente> parseConfFileEnti(XDocument conf_file, XNamespace? ns = null)
        {
            var confEnti = new List<Ente>();
            foreach (var confEnteElement in conf_file.Descendants(ns + "ente"))
            {
                var confEnte = new Ente(confEnteElement, ns);
                confEnti.Add(confEnte);
            }
            return confEnti;
        }

        // Nuova versione: riceve la lista di nodi di configurazione già parsata e segnala quelli non trovati nel file
        public List<Nodo> ParseNodi(List<Nodo> confNodi, XDocument file, string categoriaNodoInteressata, XNamespace? ns = null)
        {
            var nodiRaccolti = new List<Nodo>();

            // Dizionario dei nodi nel file filtrati per categoria con chiave composta (Nome, Categoria, Tipo)
            var nodiFileDict = file
                .Descendants(ns + "nodo")
                .Select(e => new Nodo(e, ns))
                .Where(n => n.Categoria == categoriaNodoInteressata)
                .ToDictionary(n => (n.Nome, n.Categoria, n.Tipo, n.Classe));

            // Itero sui nodi di configurazione della categoria interessata
            foreach (var confNode in confNodi)
            {
                var key = (confNode.Nome, confNode.Categoria, confNode.Tipo, confNode.Classe);
                if (nodiFileDict.TryGetValue(key, out var node))
                {
                    nodiRaccolti.Add(node);
                    var line = $" - {node.Nome,-10} {node.Classe,-15} {node.Id,6} {node.X,10} {node.Y,10}";
                    Console.WriteLine(line);
                    FileWrite.Write(line, true);
                }
                else
                {
                    var msg = $"Nodo {confNode.Nome} non trovato nel file";
                    Console.WriteLine(msg);
                    FileWrite.Write(msg, true);
                }
            }
            return nodiRaccolti;
        }

        public List<Ente> ParseEnti(List<Ente> confEnti, XDocument file, string categoriaEnteInteressata, XNamespace? ns = null)
        {
            var entiRaccolti = new List<Ente>();

            var entiFileDict = file
                .Descendants(ns + "ente")
                .Select(e => new Ente(e, ns))
                .Where(en => en.Categoria == categoriaEnteInteressata)
                .ToDictionary(en => (en.Nome, en.Categoria, en.Tipo, en.Classe));

            foreach (var confEnte in confEnti)
            {
                var key = (confEnte.Nome, confEnte.Categoria, confEnte.Tipo, confEnte.Classe);
                if (entiFileDict.TryGetValue(key, out var ente))
                {
                    entiRaccolti.Add(ente);
                    var line = $" - {ente.Nome,-10} {ente.Classe,-15} {ente.Id,6} {ente.X,10} {ente.Y,10}";
                    Console.WriteLine(line);
                    FileWrite.Write(line, true);
                }
                else
                {
                    var msg = $"Ente {confEnte.Nome} non trovato nel file";
                    Console.WriteLine(msg);
                    FileWrite.Write(msg, true);
                }
            }
            return entiRaccolti;
        }

        public bool CheckTwoFiles<T>(
            List<T> elemFile1,
            List<T> elemFile2,
            Func<T, string> getKey, //Siccome è un metodo generico , non posso usare direttamente la proprietà Nome, ma devo passare una funzione che mi restituisca la chiave
            List<Func<(T a, T b), (string fieldName, object val1, object val2)>> comparators, //Lista di funzioni che mi restituiscono il nome del campo e i due valori da confrontare (file comparators)
            string entityName = "Elemento"
            ) 
        {
            if(elemFile1 == null || elemFile2 == null)
            {
                throw new ArgumentNullException("Le liste di elementi non possono essere null.");
            }

            bool checkError = false;
            var elemFile2Dict = elemFile2.ToDictionary(getKey); //Creo un dizionario passando la getKey (definita nel file comparators)
            string line = string.Empty;

            foreach (var elem in elemFile1)
            {
                var elemName = getKey(elem);
                if (elemFile2Dict.TryGetValue(elemName, out var elem2))
                {
                    foreach (var comparer in comparators)
                    {
                        //Tramite il comparer ottengo il nome del campo e i due valori da confrontare, successivamente li confronto
                        var (fieldName, val1, val2) = comparer((elem, elem2));
                        if (!Equals(val1, val2))
                        {
                            line = $"Discrepanza trovata: {entityName} {elemName} {fieldName} diversa tra i due file --> File1: {val1} - File2: {val2}"; ;
                            Console.WriteLine(line);
                            FileWrite.Write(line, true);
                            checkError = true;
                        }
                    } 
                }
                else
                {
                    FileWrite.WriteMissingElement("secondo", entityName, elemName);
                    Logger.Log(line, false);
                    checkError = true;
                }
            }
            var nomiFile1 = elemFile1.Select(getKey).ToList(); //creo una seconda lista contenente solo i nomi per rendere più efficiente la ricerca
            foreach (var elem2 in elemFile2)
            {
                var elemName = getKey(elem2);
                if (!nomiFile1.Contains(elemName))
                {
                    FileWrite.WriteMissingElement("primo", entityName, elemName);
                    Logger.Log(line, false);
                    checkError = true;
                }
            }
            return checkError;
        }

    }
}
