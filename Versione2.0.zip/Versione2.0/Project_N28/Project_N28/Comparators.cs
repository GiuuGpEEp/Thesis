﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_N28
{
    /*
     Nel file Parser.cs è presente il metodo CheckTwoFiles che si occupa di confrontare gli enti e i nodi dei due file per cercare errori.
     Per evitare duplicazioni ho usato dei metodi generici, di conseguenza non posso accedere direttamente alle variabili, ma necessito di 
     funzioni per ottenere i valori interessati. 
     Questa classe comparators inizializza in modo corretto le funzioni interessate.
     
     Func<T, string> getKey: funzione che restituisce la chiave dell'elemento (Nome) --> Func<T, string> getKey = (T elem) => elem.Nome
     List<Func<(Nodo a, Nodo b), (string fieldName, object val1, object val2)>> NodoComparators --> lista di funzioni che restituiscono il nome del campo (id, x e y) e i due valori da confrontare (file comparators)

     */
    public static class Comparators
    {
        public static readonly Func<Nodo, string> getKeyNodo = new Func<Nodo, string>((Nodo elem) => elem.Nome);

        public static readonly Func<Ente, string> getKeyEnte = new Func<Ente, string>((Ente elem) => elem.Nome);

        public static readonly Func<Nodo, double> getIdNodo = new Func<Nodo, double>((Nodo elem) => elem.Id);

        public static readonly Func<Ente, double> getIdEnte = new Func<Ente, double>((Ente elem) => elem.Id);

        public static readonly List<Func<(Nodo a, Nodo b), (string fieldName, object val1, object val2)>> NodoComparators =
            new List<Func<(Nodo a, Nodo b), (string fieldName, object val1, object val2)>>
            {
                pair => ("Id", pair.a.Id, pair.b.Id),
                pair => ("X", pair.a.X, pair.b.X),
                pair => ("Y", pair.a.Y, pair.b.Y),
            };

        public static readonly List<Func<(Ente a, Ente b), (string fieldName, object val1, object val2)>> EnteComparators =
            new List<Func<(Ente a, Ente b), (string fieldName, object val1, object val2)>>
            {
                pair => ("Id", pair.a.Id, pair.b.Id),
                pair => ("X", pair.a.X, pair.b.X),
                pair => ("Y", pair.a.Y, pair.b.Y),
            };
    }
}
