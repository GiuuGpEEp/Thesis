﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_N28
{
    public interface IFileBrowser
    {
        public string GetFilePath(string dialogTitle);
        public string GetOutputDirectory();

    }
}
