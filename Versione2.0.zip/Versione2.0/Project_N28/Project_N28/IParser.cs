﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project_N28
{
    public interface IParser
    {
        public XDocument FileLoader(bool firstLog, string filepath);

        public string LoadNomeImpianto(XDocument conf_file, XDocument file, XNamespace? ns = null);

        public List<Nodo> parseConfFIleNodes(XDocument conf_file, XNamespace? ns = null);

        public List<Ente> parseConfFileEnti(XDocument conf_file, XNamespace? ns = null);

        public List<Nodo> ParseNodi(List<Nodo> confNodi, XDocument file, string categoriaNodoInteressata, XNamespace? ns = null);

        public List<Ente> ParseEnti(List<Ente> confEnti, XDocument file, string categoriaEnteInteressata, XNamespace? ns = null);

        public bool CheckTwoFiles<T>(
            List<T> elemFile1,
            List<T> elemFile2,
            Func<T, string> getKey, //Siccome è un metodo generico , non posso usare direttamente la proprietà Nome, ma devo passare una funzione che mi restituisca la chiave
            List<Func<(T a, T b), (string fieldName, object val1, object val2)>> comparators, //Lista di funzioni che mi restituiscono il nome del campo e i due valori da confrontare (file comparators)
            string entityName = "Elemento"
            );
    }
}
