﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_N28
{
    public static class Logger
    {
        private static string logPath = "";

        public static void SetOutputFilePath(string directory)
        {
            logPath = Path.Combine(directory, "log.txt");
        }
        public static void Log(string message, bool firstLog)
        {
            using (StreamWriter writer = new StreamWriter(logPath, append: !firstLog))
            {
                writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss:fff} - {message}");
            }
        }
    }
}