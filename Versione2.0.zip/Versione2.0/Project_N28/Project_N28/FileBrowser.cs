﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_N28
{
    public class FileBrowser : IFileBrowser
    {
        //Selezione di un file XML tramite finestra di dialogo in input
        public string GetFilePath(string dialogTitle)
        {
            //Abilita la visualizzazione delle finestre di dialogo
            Application.EnableVisualStyles();

            //Crea e configura la finestra di dialogo per l'apertura dei file usando using siamo sicuri che alla fine dell'uso l'oggetto venga eliminato e le risorse rilasciate
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = dialogTitle;
                openFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";

                if (openFileDialog.ShowDialog() == DialogResult.OK) // l'utente ha selezionato un file
                {
                    return openFileDialog.FileName;
                }
                else
                {
                    return string.Empty; // L'utente ha annullato la selezione
                }

            };  

            
        }

        //Finestra di dialogo per selezionare la cartella di output
        public string GetOutputDirectory()
        {
            Application.EnableVisualStyles();

            using (var folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Seleziona dove salvare i risultati: ";
                if(folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    return folderBrowserDialog.SelectedPath.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
                }
                else
                {
                    return string.Empty; // L'utente ha annullato la selezione
                }

            }
        }
    }
}
