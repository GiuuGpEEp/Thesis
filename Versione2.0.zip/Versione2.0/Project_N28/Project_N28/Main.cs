﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project_N28
{
    public class MainClass
    {
        private static readonly string header = $" - {"NOME",-10} {"CLASSE",-15} {"ID",6} {"X",10} {"Y",10}";
        private static readonly XNamespace ns = "http://www.sirti.it/graph";

        private readonly IParser _parser;
        private readonly IFileBrowser _fileBrowser;

        //variabili per i nomi dei file
        private string conf_filename = "";
        private string A_filename = "";
        private string B_filename = "";
        private string outputDirectory = "";


        public MainClass(IParser parser, IFileBrowser fileBrowser)
        {
            _parser = parser;
            _fileBrowser = fileBrowser;
        }


        //////////////////////////////////
        // Metodi Helper per la stampa //
        ////////////////////////////////

        public static void PrintConfigNodes(IEnumerable<Nodo> nodi)
        {
            var list = nodi?.ToList() ?? new List<Nodo>();
            if (list.Count == 0)
            {
                const string emptyMsg = "(nessun nodo di configurazione)";
                Console.WriteLine(emptyMsg);
                FileWrite.Write(emptyMsg, true);
                return;
            }

            int catW = Math.Max("CATEGORIA".Length, list.Max(n => n.Categoria?.Length ?? 0)) + 2;
            int tipoW = Math.Max("TIPO".Length, list.Max(n => n.Tipo?.Length ?? 0)) + 2;
            int nomeW = Math.Max("NOME".Length, list.Max(n => n.Nome?.Length ?? 0)) + 2;
            int classeW = Math.Max("CLASSE".Length, list.Max(n => n.Classe?.Length ?? 0)) + 2;

            string dynHeader = $"{"CATEGORIA".PadRight(catW)}{"TIPO".PadRight(tipoW)}{"NOME".PadRight(nomeW)}{"CLASSE".PadRight(classeW)}";
            Console.WriteLine(dynHeader);
            FileWrite.Write(dynHeader, true);

            foreach (var n in list)
            {
                string line = $"{(n.Categoria ?? string.Empty).PadRight(catW)}{(n.Tipo ?? string.Empty).PadRight(tipoW)}{(n.Nome ?? string.Empty).PadRight(nomeW)}{(n.Classe ?? string.Empty).PadRight(classeW)}";
                Console.WriteLine(line);
                FileWrite.Write(line, true);
            }
        }
        private static void PrintConfigEnti(IEnumerable<Ente> enti)
        {
            var list = enti?.ToList() ?? new List<Ente>();
            if (list.Count == 0)
            {
                const string emptyMsg = "(nessun ente di configurazione)";
                Console.WriteLine(emptyMsg);
                FileWrite.Write(emptyMsg, true);
                return;
            }
            int catW = Math.Max("CATEGORIA".Length, list.Max(e => e.Categoria?.Length ?? 0)) + 2;
            int tipoW = Math.Max("TIPO".Length, list.Max(e => e.Tipo?.Length ?? 0)) + 2;
            int nomeW = Math.Max("NOME".Length, list.Max(e => e.Nome?.Length ?? 0)) + 2;
            int classeW = Math.Max("CLASSE".Length, list.Max(e => e.Classe?.Length ?? 0)) + 2;
            string dynHeader = $"{"CATEGORIA".PadRight(catW)}{"TIPO".PadRight(tipoW)}{"NOME".PadRight(nomeW)}{"CLASSE".PadRight(classeW)}";
            Console.WriteLine(dynHeader);
            FileWrite.Write(dynHeader, true);
            foreach (var e in list)
            {
                string line = $"{(e.Categoria ?? string.Empty).PadRight(catW)}{(e.Tipo ?? string.Empty).PadRight(tipoW)}{(e.Nome ?? string.Empty).PadRight(nomeW)}{(e.Classe ?? string.Empty).PadRight(classeW)}";
                Console.WriteLine(line);
                FileWrite.Write(line, true);
            }
        }

        ///////////
        // Main //
        /////////

        [STAThread]
        static void Main(string[] args)
        {
            var fileBrowser = new FileBrowser();
            var parser = new Parser();
            var mainClass = new MainClass(parser, fileBrowser);
            mainClass.Run();
        }

        public void Run()
        {
            // Richiesta dei file all'utente
            conf_filename = _fileBrowser.GetFilePath("Seleziona il file di configurazione (config.xml)");
            A_filename = _fileBrowser.GetFilePath("Seleziona il file TOOL_A (tool_a.xml)");
            B_filename = _fileBrowser.GetFilePath("Seleziona il file TOOL_B (tool_b.xml)");

            if (string.IsNullOrEmpty(conf_filename) || string.IsNullOrEmpty(A_filename) || string.IsNullOrEmpty(B_filename))
            {
                Console.WriteLine("Errore: uno o più file non sono stati selezionati. Uscita dal programma.");
                return;
            }

            // Richiesta della cartella di output
            outputDirectory = _fileBrowser.GetOutputDirectory();
            if (string.IsNullOrEmpty(outputDirectory))
            {
                Console.WriteLine("Errore: cartella di output non selezionata. Uscita dal programma.");
                return;
            }

            // Imposto i percorso di output per i file di log, report e mapping
            Mapping.SetOutputFilePath(outputDirectory);
            FileWrite.SetOutputFilePath(outputDirectory);
            Logger.SetOutputFilePath(outputDirectory);

            bool firstLog = true;
            bool firstline = false;
            string categoriaNodoInteressata = "DEVIATOIO";
            string categoriaEnteInteressata = "CDB";

            // Carico i file XML
            XDocument conf_file = _parser.FileLoader(firstLog, conf_filename);
            firstLog = false;
            XDocument fileA = _parser.FileLoader(firstLog, A_filename);
            XDocument fileB = _parser.FileLoader(firstLog, B_filename);

            // Carico il nome dell'impianto
            Logger.Log("Accesso ai file XML per cercare il nome dell'impianto: ", firstLog);
            string nomeImpianto = _parser.LoadNomeImpianto(conf_file, fileA, ns);
            Logger.Log("Nome dell'impianto ottenuto con successo: " + nomeImpianto, firstLog);
            FileWrite.Write("Ci troviamo nell'impianto di " + nomeImpianto + "\n", firstline);
            firstline = true;

            // Carico i nodi nel file di configurazione
            Logger.Log("Caricamento nodi di configurazione iniziato", firstLog);
            Console.WriteLine("Nodi di configurazione:");
            FileWrite.Write("Nodi di configurazione:", firstline);
            List<Nodo> confNodi = _parser.parseConfFIleNodes(conf_file, ns);
            Logger.Log("Caricamento nodi di configurazione terminato: " + confNodi.Count + " nodi trovati", firstLog);
            PrintConfigNodes(confNodi); // nuova stampa formattata

            //Carico gli enti nel file di configurazione
            Logger.Log("Caricamento enti di configurazione iniziato", firstLog);
            Console.WriteLine("\nEnti di configurazione:");
            FileWrite.Write("\nEnti di configurazione:", firstline);
            List<Ente> confEnti = _parser.parseConfFileEnti(conf_file, ns);
            Logger.Log("Caricamento enti di configurazione terminato: " + confEnti.Count + " enti trovati", firstLog);
            PrintConfigEnti(confEnti); // nuova stampa formattata

            Console.WriteLine("\n-----------------------------------------------------------------------------");
            FileWrite.Write("\n-----------------------------------------------------------------------------", firstline);

            // Carico i nodi
            Logger.Log("Ricerca nodi iniziata, categoria: " + categoriaNodoInteressata, firstLog);
            Console.WriteLine("\nRicerca nodi iniziata, categoria: " + categoriaNodoInteressata);
            FileWrite.Write("\nRicerca di nodi di tipo: " + categoriaNodoInteressata + "...", firstline);

            Console.WriteLine($"\nRisultati da TOOL_A:\n{header}");
            FileWrite.Write($"\nRisultati da TOOL_A:\n{header}", firstline);

            List<Nodo> nodiA = _parser.ParseNodi(confNodi, fileA, categoriaNodoInteressata, ns);
            Logger.Log("Ricerca nodi nel tool A terminata: " + nodiA.Count + " nodi trovati", firstLog);

            Console.WriteLine($"\nRisultati da TOOL_B:\n{header}");
            FileWrite.Write($"\nRisultati da TOOL_B:\n{header}", firstline);

            List<Nodo> nodiB = _parser.ParseNodi(confNodi, fileB, categoriaNodoInteressata, ns);
            Logger.Log("Ricerca nodi nel tool B terminata: " + nodiB.Count + " nodi trovati", firstLog);

            // Confronto i risultati per cercare errori
            Logger.Log("Ricerca di eventuali incongruenze nei nodi tra i due file...", firstLog);
            Console.WriteLine($"\nRicerca di eventuali incongruenze nei nodi tra i due file:");
            FileWrite.Write($"\nRicerca di eventuali incongruenze nei nodi tra i due file:", firstline);

            bool errorFound = _parser.CheckTwoFiles(
                nodiA,
                nodiB,
                Comparators.getKeyNodo,
                Comparators.NodoComparators,
                "Nodo"
                );

            if (errorFound) Logger.Log("Discrepanze nei nodi trovate tra i due file; Controllare il Report.txt per i dettagli", firstLog);

            if (!errorFound)
            {
                Logger.Log("Nessuna differenza nei nodi trovata tra i due file", firstLog);
                Console.WriteLine("Nessuna differenza nei nodi trovata tra i due file");
                FileWrite.Write("Nessuna differenza nei nodi trovata tra i due file", firstline);
            }

            // Carico gli enti
            Logger.Log("Ricerca enti iniziata, categoria: " + categoriaEnteInteressata, firstLog);
            Console.WriteLine("\nRicerca enti iniziata, categoria: " + categoriaEnteInteressata);
            FileWrite.Write("\nRicerca di enti di tipo: " + categoriaEnteInteressata + "...", firstline);

            Console.WriteLine($"\nRisultati da TOOL_A:\n{header}");
            FileWrite.Write($"\nRisultati da TOOL_A:\n{header}", firstline);
            List<Ente> entiA = _parser.ParseEnti(confEnti, fileA, categoriaEnteInteressata, ns);

            Logger.Log("Ricerca enti nel tool A terminata: " + entiA.Count + " enti trovati", firstLog);
            Console.WriteLine($"\nRisultati da TOOL_B:\n{header}");
            FileWrite.Write($"\nRisultati da TOOL_B:\n{header}", firstline);

            List<Ente> entiB = _parser.ParseEnti(confEnti, fileB, categoriaEnteInteressata, ns);
            Logger.Log("Ricerca enti nel tool B terminata: " + entiB.Count + " enti trovati", firstLog);

            // Confronto i risultati per cercare errori
            Logger.Log("Ricerca di eventuali incongruenze negli enti tra i due file...", firstLog);
            Console.WriteLine($"\nRicerca di eventuali incongruenze negli enti tra i due file:");
            FileWrite.Write($"\nRicerca di eventuali incongruenze negli enti tra i due file:", firstline);

            errorFound = _parser.CheckTwoFiles(
                entiA,
                entiB,
                Comparators.getKeyEnte,
                Comparators.EnteComparators,
                "Ente"
            );

            if (errorFound) Logger.Log("Discrepanze negli enti trovate tra i due file; Controllare il Report.txt per i dettagli", firstLog);

            if (!errorFound)
            {
                Logger.Log("Nessuna differenza negli enti trovata tra i due file", firstLog);
                Console.WriteLine("Nessuna differenza negli enti trovata tra i due file");
                FileWrite.Write("Nessuna differenza negli enti trovata tra i due file", firstline);
            }
            bool appendXML = false;
            var nodiMapping = Mapping.BuildMapFile(nodiA, nodiB, Comparators.getKeyNodo, Comparators.getIdNodo, "Nodo");

            if (nodiMapping.Count > 0)
            {
                Logger.Log("Mappatura nodi completata con successo", firstLog);
                Mapping.WriteMapToXML(nodiMapping, appendXML);
            }
            else
            {
                Logger.Log("Nessuna mappatura nodi possibile tra i due file", firstLog);
            }

            appendXML = true;
            var entiMapping = Mapping.BuildMapFile(entiA, entiB, Comparators.getKeyEnte, Comparators.getIdEnte, "Ente");

            if (entiMapping.Count > 0)
            {
                Logger.Log("Mappatura enti completata con successo", firstLog);
                Mapping.WriteMapToXML(entiMapping, appendXML);
            }
            else
            {
                Logger.Log("Nessuna mappatura enti possibile tra i due file", firstLog);
            }
        }
    }
}
