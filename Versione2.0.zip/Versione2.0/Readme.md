## Perricone Giuseppe Versione 2.0 del codice 

Il progetto è così organizzato:
- All'interno della stessa cartella della solution sono presenti
    - TOOL_A --> cartella contenente il file XML con i dati del TOOL_A
    - TOOL_B --> cartella contenente il file XML con i dati del TOOL_B
    - ConFile.xml --> File di configurazione
    - Results --> cartella dove vengono salvati il file di log.txt e report.txt

- Project_N28 cartella contenente i file.cs del progetto:
    - Comparators.cs --> File contente alcune funzioni usate principalmente per estrazione di features utilizzabili in metodi generici
    - FileWrite.cs --> File contenente metodi per scrivere il report finale
    - Logger.cs --> File contenente metodi per scrivere i Logger
    - Main.cs 
    - Parser.cs --> File contenente tutti i metodi per caricare e fare il parsing dei file XML in input
    - XML_Elem.cs --> File contenente le classi che raffigurano gli oggetti XML        

L'output è così organizzato:
- Elenco di ciò che è stato trovato sul TOOL_A 
- Elenco di ciò che è stato trovato sul TOOL_B
- Parte di rilevazione degli errori, dove vengono mostrate le differenze effettive tra i due file

Per il momento vengono cercati unicamente:
- Nodi della categoria DEVIATOI
- Enti della categoria CDB
Per far ciò ho costruito il file di configurazione inserendo tutti i nodi e gli enti che rispecchiano questa caratteristica

Il programma controlla che:
- All'interno del TOOL_A e del TOOL_B siano presenti gli elementi del file di configurazione
- Se l'elemento viene trovato solo in uno dei due file il programma indica in quale dei due l'elemento non è presente
- Se invece l'elemento viene trovato in entrambi i file si controlla se l'elemento possiede gli stessi id, x e y su entrambi i file

